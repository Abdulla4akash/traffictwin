# TrafficTwin VEC end-to-end reproducibility artifact

This deterministic VEC-12 archive reconciles the accepted VEC-01 through VEC-11 contracts and evidence. Verify it offline with:

```bash
traffictwin integration vec research-verify vec_end_to_end_research_artifact.zip
```

The VEC-08 protocol-seed reproduction is distinct from the VEC-09/VEC-11 `_s102` best-of-seeds scientific result. The archive embeds no raw source or execution bytes, checkpoint, source identity mapping, private path, or third-party SUMO asset. Pseudonymisation is not anonymity. Owner permission is not a formal licence, and public hosting remains unauthorised. See `manifest.json`, `provenance.json`, and `limitations.json` for the machine-readable boundary.
